import 'package:flutter/material.dart';

// Importa os arquivos onde estão as classes das outras telas.
// Certifique-se de que os nomes dos arquivos estão corretos.
import 'login_screen.dart'; 
import 'register_screen.dart'; 
import 'create_event_screen.dart';
import 'ingresso_screen.dart';
import 'view_event_screen.dart';
import 'event_invite_screen.dart'; // Certifique-se de que este import está correto

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Define a tela inicial do aplicativo
    return MaterialApp(
      title: 'TicketHub App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // A tela inicial agora é a HomeScreen
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
        centerTitle: true,
      ),
      body: Center(
        child: SingleChildScrollView( // Adicionado SingleChildScrollView para evitar overflow
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Bem-vindo ao TicketHub!',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 50),
              // Botão para a tela de Login
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const LoginScreen()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                ),
                child: const Text('Ir para Tela de Login'),
              ),
              const SizedBox(height: 20),
              // Botão para a tela de Criar Evento
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const CreateEventScreen()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                ),
                child: const Text('Ir para Tela de Criar Evento'),
              ),
              const SizedBox(height: 20),
              // Botão para a tela de ver evento
              ElevatedButton(
                onPressed: () {
                  // Mudei o nome da classe, se ela for a 'ViewEventScreen'
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const InviteCenterScreen()), 
                  );
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                ),
                child: const Text('Ir para Tela de Ver Evento'),
              ),
              const SizedBox(height: 20),
              // Botão para a tela de ingresso
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const TicketScreen()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                ),
                child: const Text('Ir para Tela de Ingresso'),
              ),
              const SizedBox(height: 20),
              // Botão para a tela de event invite (Convite) - CORREÇÃO APLICADA AQUI
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const EventInviteScreen(
                        // ⭐️ DADOS FICTÍCIOS ADICIONADOS ⭐️
                        nomeEvento: 'Show de Rock Anual', 
                        dataEvento: '15/10/2025',
                        horarioEvento: '20:00',
                        localEvento: 'Arena da Cidade',
                        descricaoEvento: 'Prepare-se para uma noite épica com as melhores bandas de rock da região. Ingressos limitados!',
                      ),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                ),
                child: const Text('Ir para Tela de Convite do Evento'),
              ),
              const SizedBox(height: 20),
              // Botão para a tela de ingresso
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const RegisterScreen()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                ),
                child: const Text('Ir para Tela de Ingresso'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}