import 'package:flutter/material.dart';

class RegisterScreen extends StatelessWidget {
  const RegisterScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Definindo o estilo de borda para reutilização
    final outlineInputBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(8.0),
      borderSide: const BorderSide(color: Colors.grey),
    );

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        // Adiciona um botão de voltar, comum em telas de registro
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: 20),
              // Logo
              // Substitua pelo seu asset de imagem real
              Image.asset(
                '../assets/tickethub_logo.png', // Atualize com o seu caminho de imagem
                height: 100, // Um pouco menor para dar espaço aos campos extras
              ),

              const SizedBox(height: 24),
              // Tagline atualizada
              const Text(
                'Crie sua conta e comece a sua jornada de eventos',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.grey,
                ),
              ),

              const SizedBox(height: 40),
              // 1. Campo Nome
              TextField(
                decoration: InputDecoration(
                  hintText: 'digite seu nome completo',
                  suffixIcon: const Icon(Icons.person),
                  border: outlineInputBorder,
                  focusedBorder: outlineInputBorder,
                ),
              ),

              const SizedBox(height: 16),
              // 2. Campo Email
              TextField(
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  hintText: 'digite seu email',
                  suffixIcon: const Icon(Icons.email),
                  border: outlineInputBorder,
                  focusedBorder: outlineInputBorder,
                ),
              ),

              const SizedBox(height: 16),
              // 3. Campo Senha
              TextField(
                obscureText: true,
                decoration: InputDecoration(
                  hintText: 'digite sua senha',
                  suffixIcon: const Icon(Icons.lock),
                  border: outlineInputBorder,
                  focusedBorder: outlineInputBorder,
                ),
              ),

              const SizedBox(height: 16),
              // 4. Campo Confirmar Senha (Novo)
              TextField(
                obscureText: true,
                decoration: InputDecoration(
                  hintText: 'confirme sua senha',
                  suffixIcon: const Icon(Icons.check_circle_outline),
                  border: outlineInputBorder,
                  focusedBorder: outlineInputBorder,
                ),
              ),

              const SizedBox(height: 48),
              // Botão de Cadastro
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    // Lógica para processar o cadastro
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFF7945A), // Cor Laranja
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: const Text(
                    'Cadastrar',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 24),
              // Seção de registro com o Google
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'ou cadastre-se com o google',
                    style: TextStyle(color: Colors.grey),
                  ),
                  const SizedBox(width: 8),
                  Image.asset(
                    '../assets/google_logo.png', // Atualize com o seu ícone do Google
                    height: 24,
                  ),
                ],
              ),
              const SizedBox(height: 40), // Espaço inferior
            ],
          ),
        ),
      ),
    );
  }
}
