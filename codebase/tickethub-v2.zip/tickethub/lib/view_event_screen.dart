import 'package:flutter/material.dart';

// Definindo as cores com base na tela de Login e no seu código anterior
const Color kBlue = Color(0xFF53A9FF); // Azul das abas ativas
const Color kOrange = Color(0xFFF7945A); // Laranja dos botões (cor do botão de login)
// A cor original do seu botão era Color(0xFFFF7A3D). Mudei para a do login (0xFFF7945A)
const Color kText = Color(0xFF2F2F2F);
const Color kSubText = Color(0xFF8A8A8A);
const Color kChipBg = Color(0xFFF1F3F5);
const Color kCardShadow = Color(0x1A000000);

class InviteCenterScreen extends StatefulWidget {
  const InviteCenterScreen({super.key});

  @override
  State<InviteCenterScreen> createState() => _InviteCenterScreenState();
}

class _InviteCenterScreenState extends State<InviteCenterScreen> {
  int _currentTab = 0;

  @override
  Widget build(BuildContext context) {
    // Para simplificar, vou manter a lógica de padding e tamanho da tela
    const horizontal = 24.0; // Adotando o padding horizontal do LoginScreen

    return Scaffold(
      backgroundColor: Colors.white, // Adotando o background do LoginScreen
      body: SafeArea(
        child: SingleChildScrollView(
          // Adotando o padding horizontal do LoginScreen
          padding: const EdgeInsets.symmetric(horizontal: horizontal, vertical: 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Cabeçalho com avatar e cumprimento
              Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: const BoxDecoration(
                      color: Color(0xFFEAF5FF),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.person, color: kBlue),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    'Olá, Iago ...',
                    // Estilo de texto mais próximo de um texto simples/médio
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: kText,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Text(
                'Central de Convites',
                // Estilo para título grande
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: kText,
                ),
              ),
              const SizedBox(height: 12),

              // Abas segmentadas
              _SegmentedTabs(
                tabs: const ['Pendentes', 'Concluídos', 'Rascunhos'],
                selected: _currentTab,
                onChanged: (i) => setState(() => _currentTab = i),
              ),
              const SizedBox(height: 14),

              // Botão "Criar Convite"
              _PrimaryButton(
                label: 'Criar Convite',
                onTap: () {
                  // Lógica para criar convite
                },
                color: kOrange,
                leading: const _CircleIcon(
                    icon: Icons.add, bg: Colors.white, fg: kOrange),
              ),
              const SizedBox(height: 14),

              // CARD 1 - Proprietário + engrenagem
              const _InviteCard(
                title: 'Festa de Aniversário ANA',
                date: '25 de Maio de 2024',
                time: '6:30 PM',
                roleLabel: 'Proprietário',
                showSettings: true,
              ),
              const SizedBox(height: 8),

              // Botão "Entrar Evento"
              _PrimaryButton(
                label: 'Entrar Evento',
                onTap: () {
                  // Lógica para entrar no evento
                },
                color: kOrange,
                leading: const _CircleIcon(
                    icon: Icons.login, bg: Colors.white, fg: kOrange),
              ),
              const SizedBox(height: 12),

              // CARD 2 - Convidado
              const _InviteCard(
                title: 'Casamento José Carlos',
                date: '31 de Agosto de 2024',
                time: '8:00 PM',
                roleLabel: 'Convidado',
                showSettings: false,
              ),
              const SizedBox(height: 12),

              // CARD 3 - Convidado
              const _InviteCard(
                title: 'Show do DJ Música',
                date: '02 de Novembro de 2024',
                time: '22:00 PM',
                roleLabel: 'Convidado',
                showSettings: false,
              ),

              // respiro inferior
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------- Widgets de UI Corrigidos ----------------------------

class _SegmentedTabs extends StatelessWidget {
  const _SegmentedTabs({
    required this.tabs,
    required this.selected,
    required this.onChanged,
  });

  final List<String> tabs;
  final int selected;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: kChipBg, // Cor de fundo das abas
        borderRadius: BorderRadius.circular(12),
      ),
      padding: const EdgeInsets.all(4),
      child: Row(
        children: List.generate(tabs.length, (i) {
          final active = i == selected;
          return Expanded(
            child: InkWell(
              borderRadius: BorderRadius.circular(10),
              onTap: () => onChanged(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  color: active ? kBlue : Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                ),
                alignment: Alignment.center,
                child: Text(
                  tabs[i],
                  // Estilo de texto com base no padrão do LoginScreen
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: active ? Colors.white : const Color(0xFF6B6B6B),
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  const _PrimaryButton({
    required this.label,
    required this.onTap,
    required this.color,
    this.leading,
  });

  final String label;
  final VoidCallback onTap;
  final Color color;
  final Widget? leading;

  @override
  Widget build(BuildContext context) {
    // Uso de ElevatedButton para se assemelhar mais ao botão de Login
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          padding: const EdgeInsets.symmetric(vertical: 10), // Padding ajustado
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          elevation: 1.5, // Adicionando elevação
          shadowColor: kCardShadow,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (leading != null) ...[
              leading!,
              const SizedBox(width: 10),
            ],
            Text(
              label,
              // Estilo de texto com base no padrão do LoginScreen
              style: const TextStyle(
                fontSize: 16,
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CircleIcon extends StatelessWidget {
  const _CircleIcon({
    required this.icon,
    required this.bg,
    required this.fg,
  });

  final IconData icon;
  final Color bg;
  final Color fg;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 26,
      height: 26,
      decoration: BoxDecoration(color: bg, shape: BoxShape.circle),
      child: Icon(icon, size: 18, color: fg),
    );
  }
}

class _InviteCard extends StatelessWidget {
  const _InviteCard({
    required this.title,
    required this.date,
    required this.time,
    required this.roleLabel,
    required this.showSettings,
  });

  final String title;
  final String date;
  final String time;
  final String roleLabel;
  final bool showSettings;

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 1.5,
      shadowColor: kCardShadow,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Conteúdo à esquerda
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    // Estilo de texto (título do card)
                    style: const TextStyle(
                        fontSize: 14, fontWeight: FontWeight.bold, color: kText),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    date,
                    // Estilo de texto (data)
                    style: const TextStyle(
                        fontSize: 12, fontWeight: FontWeight.w600, color: kSubText),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.access_time, size: 15, color: kSubText),
                      const SizedBox(width: 4),
                      Text(
                        time,
                        // Estilo de texto (hora)
                        style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: kSubText),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Ícones à direita (engrenagem + papel de usuário)
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (showSettings) ...[
                  const Icon(Icons.settings, size: 18, color: Colors.black87),
                  const SizedBox(width: 10),
                ],
                Column(
                  children: [
                    const Icon(Icons.person, size: 18, color: Colors.black87),
                    const SizedBox(height: 4),
                    Text(
                      roleLabel,
                      // Estilo de texto (papel do usuário)
                      style: const TextStyle(
                          fontSize: 10, fontWeight: FontWeight.bold, color: kSubText),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}