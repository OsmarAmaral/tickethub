package com.example.tickethub

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
