import 'package:flutter/material.dart';

// Importa os arquivos onde estão as classes das outras telas.
// Certifique-se de que os nomes dos arquivos estão corretos.
import 'login_screen.dart'; 
import 'create_event_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Define a tela inicial do aplicativo
    return MaterialApp(
      title: 'TicketHub App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // A tela inicial agora é a HomeScreen
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Bem-vindo ao TicketHub!',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 50),
            // Botão para a tela de Login
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const LoginScreen()),
                );
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
              ),
              child: const Text('Ir para Tela de Login'),
            ),
            const SizedBox(height: 20),
            // Botão para a tela de Criar Evento
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const CreateEventScreen()),
                );
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
              ),
              child: const Text('Ir para Tela de Criar Evento'),
            ),
          ],
        ),
      ),
    );
  }
}

// As classes LoginScreen e CreateEventScreen, que você já tem, devem ficar
// em arquivos separados para que os imports funcionem corretamente.
// Ex: 'login_screen.dart' e 'create_event_screen.dart'

// CÓDIGO DA LoginScreen (do seu prompt anterior, em um arquivo separado)
// class LoginScreen extends StatelessWidget { ... }

// CÓDIGO DA CreateEventScreen (do seu prompt anterior, em um arquivo separado)
// class CreateEventScreen extends StatefulWidget { ... }